package com.accenture.market;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccentureMarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
